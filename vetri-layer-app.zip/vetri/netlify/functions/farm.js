const { GITHUB_TOKEN, GITHUB_REPO, GITHUB_BRANCH = "main", APP_PIN } = process.env;
const FILE = "data/farm.json";
const url = `https://api.github.com/repos/${GITHUB_REPO}/contents/${FILE}`;
const H = { Authorization: `Bearer ${GITHUB_TOKEN}`, Accept: "application/vnd.github+json", "User-Agent": "vetri-layer" };
const res = (code, obj) => ({ statusCode: code, headers: { "Content-Type": "application/json" }, body: JSON.stringify(obj) });

async function read() {
  const r = await fetch(`${url}?ref=${GITHUB_BRANCH}`, { headers: H });
  if (r.status === 404) return { data: { setups: {}, entries: [] }, sha: undefined };
  if (!r.ok) throw new Error("GitHub read " + r.status);
  const j = await r.json();
  return { data: JSON.parse(Buffer.from(j.content, "base64").toString("utf8")), sha: j.sha };
}
async function write(data, sha, message) {
  return fetch(url, {
    method: "PUT", headers: H,
    body: JSON.stringify({ message, branch: GITHUB_BRANCH, sha, content: Buffer.from(JSON.stringify(data, null, 1)).toString("base64") }),
  });
}
function apply(data, b) {
  if (b.action === "setup") {
    if (!data.setups[b.batch]) data.setups[b.batch] = { startDate: b.startDate, initialStock: b.initialStock }; // locked once set
    return `setup ${b.batch}`;
  }
  if (b.action === "entry") {
    const e = b.entry;
    data.entries = data.entries.filter((x) => !(x.batch === e.batch && x.date === e.date));
    data.entries.push(e);
    data.entries.sort((x, y) => y.date.localeCompare(x.date));
    return `entry ${e.batch} ${e.date}`;
  }
  if (b.action === "delete") {
    data.entries = data.entries.filter((x) => x.id !== b.id);
    return `delete ${b.id}`;
  }
  throw new Error("bad action");
}

exports.handler = async (event) => {
  if (!APP_PIN || event.headers["x-app-pin"] !== APP_PIN) return res(401, { error: "unauthorized" });
  try {
    if (event.httpMethod === "GET") return res(200, (await read()).data);
    if (event.httpMethod !== "POST") return res(405, {});
    const body = JSON.parse(event.body || "{}");
    for (let i = 0; i < 3; i++) {
      const { data, sha } = await read();
      const msg = apply(data, body);
      const r = await write(data, sha, msg);
      if (r.ok) return res(200, { ok: true });
      if (r.status !== 409 && r.status !== 422) throw new Error("GitHub write " + r.status);
    }
    return res(409, { error: "conflict" });
  } catch (e) {
    return res(500, { error: e.message });
  }
};
